<footer class="page-footer bg-dark">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2020 Copyright: Made by
            <a href="">BullAnt Tech</a>
            <div style="margin-left: 30px;"> developer contact: +91 9120231512 </div>
        </div>
        <!-- Copyright -->

</footer>