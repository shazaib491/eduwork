<?php
include "head.php";
?>

<body>
    <?php
    include "navbar.php";
    ?>

    <section class="home-slider owl-carousel" style="margin-bottom: 50px;">
        <div class="slider-item" style="background-image:url(images/bg3.png);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row no-gutters slider-text align-items-center justify-content-start"
                    data-scrollax-parent="true">
                    <div class="col-md-6 ftco-animate">
                        <h1 class="mb-4">Eduwork educational initiatives</h1>
                        <p>Shaping the future together
                        </p>
                        <p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Contact Us</a></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="slider-item" style="background-image:url(images/bg2.png);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row no-gutters slider-text align-items-center justify-content-start"
                    data-scrollax-parent="true">
                    <div class="col-md-6 ftco-animate">
                        <h1 class="mb-4">Eduwork educational initiatives</h1>
                        <p>Shaping the future together
                        </p>
                        <p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Contact Us</a></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-services ftco-no-pb" style="margin-bottom: 50px;">
        <h2 align="center" style="margin-bottom: 20px;">Campus Recruitment Training</h2>
        <div class="container-wrap">
            <div class="row no-gutters">
                <div class="col-md-4 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-darken">
                    <div class="media block-6 d-block text-center">
                        <div class="icon d-flex justify-content-center align-items-center">
                            <span class="flaticon-diploma"></span>
                        </div>
                        <div class="media-body p-2 mt-3">
                            <h3 class="heading">Resume building</h3>
                            <p>Our team of professionals who have expertise in recruiting, interviewing, content, typography, and design will ensure that you get a resume that is significantly better than your previous one.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-primary">
                    <div class="media block-6 d-block text-center">
                        <div class="icon d-flex justify-content-center align-items-center">
                            <span class="flaticon-teacher"></span>
                        </div>
                        <div class="media-body p-2 mt-3">
                            <h3 class="heading">Softskills / Communication</h3>
                            <p>Facing your interview or gaining confidence at a workplace, let it be anything, all you need is a professional Soft Skills Training to make you interview ready or work ready.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-darken">
                    <div class="media block-6 d-block text-center">
                        <div class="icon d-flex justify-content-center align-items-center">
                            <span class="flaticon-reading"></span>
                        </div>
                        <div class="media-body p-2 mt-3">
                            <h3 class="heading">Communication</h3>
                            <p>Communication, leadership, teamwork, presentation, problem-solving are some of the skills that any company would look for in any candidate sitting for an interview.</p>
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </section>

    <section class="ftco-section ftco-no-pt ftc-no-pb" style="margin-bottom: 50px;">
        <div class="container">
            <div class="row d-flex">
                <div class="col-md-5 order-md-last wrap-about wrap-about d-flex align-items-stretch">
                    <div class="img" style="background-image: url(images/bg3.png);"></div>
                </div>
                <div class="col-md-7 wrap-about py-5 pr-md-4 ftco-animate">
                    <h2 class="mb-4">Our services</h2>
                    <p>Eduworks Educational Initiatives, is involved into sales, marketing & distribution of Educational Solutions (Competitions, Soft skill Training Programs, Cutting Edge Technology Training Programs, E-Learning Contents, eCampus Solutions etc.) to Institutions like Schools, Universities, Engineering Colleges, Management Colleges, etc. throughout Madhya Pradesh & Chhattisgarh & in near future plan to have offices PAN India; over the years we have worked with leading companies in diversified sectors, in E-learning, Software Services, Training, Campus Placement etc. to name a few.
                    </p>
                    <p>Eduworks has continually taken a lead role in setting new standards in the sales, marketing & distribution of IT solutions and value-add services. We cater to the requirement of Institution, Corporate, Government and Individual clients. Today, Eduworks has multiple product lines which are the most in-demand products.</p>
                </div>
            </div>
        </div>
    </section>
    <h2 align="center" style="margin-bottom: 20px;">Our acheivements</h2>
    <section class="home-slider owl-carousel" style="margin-bottom: 50px;">
        <div class="slider-item" style="background-image:url(images/glr1.png);">
        </div>

        <div class="slider-item" style="background-image:url(images/glr2.png);">
        </div>

        <div class="slider-item" style="background-image:url(images/glr3.png);">
        </div>
    </section>

    <section class="ftco-section testimony-section">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-8 text-center heading-section ftco-animate">
                    <h2 class="mb-4">What Student Says About Us</h2>
                </div>
            </div>
            <div class="row ftco-animate justify-content-center">
                <div class="col-md-12">
                    <div class="carousel-testimony owl-carousel">
                        <div class="item">
                            <div class="testimony-wrap d-flex">
                                <div class="user-img mr-4" style="background-image: url(images/user.png)">
                                </div>
                                <div class="text ml-2">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                    <p>Eduwork help me to prepare for my campus Placements</p>
                                    <p class="name">User</p>
                                    <span class="position">Student</span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap d-flex">
                                <div class="user-img mr-4" style="background-image: url(images/user.png)">
                                </div>
                                <div class="text ml-2">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                    <p>Eduwork provide me the best internship program and help me to learn</p>
                                    <p class="name">user</p>
                                    <span class="position">Student</span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap d-flex">
                                <div class="user-img mr-4" style="background-image: url(images/user.png)">
                                </div>
                                <div class="text ml-2">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                    <p>Eduwork helps me to improve my soft skills and communication</p>
                                    <p class="name">user</p>
                                    <span class="position">Student</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section ftco-consult ftco-no-pt ftco-no-pb" style="background-image: url(images/bg2.png);"
        data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-md-12">
                    <div class="py-md-5">
                        <div class="heading-section heading-section-white ftco-animate mb-5">
                            <h2 class="mb-4">Contact Us</h2>
                        </div>
                        <form action="#" class="appointment-form ftco-animate">
                            <div class="d-md-flex">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="First Name">
                                </div>
                                <div class="form-group ml-md-4">
                                    <input type="text" class="form-control" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="d-md-flex">
                                <div class="form-group">
                                    <div class="form-field">
                                        <div class="select-wrap">
                                            <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                                            <select name="" id="" class="form-control">
                                                <option value="">Select Your Course</option>
                                                <option value="">Art Lesson</option>
                                                <option value="">Language Lesson</option>
                                                <option value="">Music Lesson</option>
                                                <option value="">Sports</option>
                                                <option value="">Other Services</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group ml-md-4">
                                    <input type="text" class="form-control" placeholder="Phone">
                                </div>
                            </div>
                            <div class="d-md-flex">
                                <div class="form-group">
                                    <textarea name="" id="" cols="30" rows="2" class="form-control"
                                        placeholder="Message"></textarea>
                                </div>
                                <div class="form-group ml-md-4">
                                    <input type="submit" value="Submit" class="btn btn-primary py-3 px-4">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
    include "footer.php";
    ?>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
                stroke="#F96D00" /></svg></div>


    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>

</body>

</html>